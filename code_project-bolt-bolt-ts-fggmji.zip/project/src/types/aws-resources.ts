export interface EC2Resource {
  instanceId: string;
  instanceType: string;
  state: string;
  tags: Record<string, string>;
}

export interface S3Resource {
  bucketName: string;
  creationDate: Date;
  region: string;
}

export interface RDSResource {
  dbIdentifier: string;
  engine: string;
  status: string;
  size: string;
}

export interface LambdaResource {
  functionName: string;
  runtime: string;
  memory: number;
  timeout: number;
}

export interface AWSResourceReport {
  ec2Instances: EC2Resource[];
  s3Buckets: S3Resource[];
  rdsDatabases: RDSResource[];
  lambdaFunctions: LambdaResource[];
  scanDate: Date;
}