import { AWSResourceScanner } from './scanner';

async function main() {
  try {
    const region = process.env.AWS_REGION || 'us-east-1';
    console.log(`Starting AWS resource scan in region: ${region}`);
    
    const scanner = new AWSResourceScanner(region);
    const report = await scanner.scanResources();
    
    console.log('\nAWS Resource Scan Report');
    console.log('======================');
    console.log(`Scan Date: ${report.scanDate.toISOString()}\n`);
    
    console.log('EC2 Instances:', report.ec2Instances.length);
    console.log('S3 Buckets:', report.s3Buckets.length);
    console.log('RDS Databases:', report.rdsDatabases.length);
    console.log('Lambda Functions:', report.lambdaFunctions.length);
    
    console.log('\nDetailed Resources:');
    console.log(JSON.stringify(report, null, 2));
  } catch (error) {
    console.error('Error during scan:', error);
    process.exit(1);
  }
}

main();