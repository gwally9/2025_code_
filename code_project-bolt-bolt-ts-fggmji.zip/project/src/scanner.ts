import { EC2Scanner } from './services/ec2-scanner';
import { S3Scanner } from './services/s3-scanner';
import { RDSScanner } from './services/rds-scanner';
import { LambdaScanner } from './services/lambda-scanner';
import type { AWSResourceReport } from './types/aws-resources';

export class AWSResourceScanner {
  private region: string;

  constructor(region: string = 'us-east-1') {
    this.region = region;
  }

  async scanResources(): Promise<AWSResourceReport> {
    const [
      ec2Instances,
      s3Buckets,
      rdsDatabases,
      lambdaFunctions
    ] = await Promise.all([
      new EC2Scanner(this.region).scanResources(),
      new S3Scanner(this.region).scanResources(),
      new RDSScanner(this.region).scanResources(),
      new LambdaScanner(this.region).scanResources()
    ]);

    return {
      ec2Instances,
      s3Buckets,
      rdsDatabases,
      lambdaFunctions,
      scanDate: new Date()
    };
  }
}