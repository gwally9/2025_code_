import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";
import type { S3Resource } from "../types/aws-resources";

export class S3Scanner {
  private client: S3Client;

  constructor(region: string) {
    this.client = new S3Client({ region });
  }

  async scanResources(): Promise<S3Resource[]> {
    try {
      const command = new ListBucketsCommand({});
      const response = await this.client.send(command);
      
      return (response.Buckets || []).map(bucket => ({
        bucketName: bucket.Name || '',
        creationDate: bucket.CreationDate || new Date(),
        region: this.client.config.region || ''
      }));
    } catch (error) {
      console.error('Error scanning S3 resources:', error);
      return [];
    }
  }
}