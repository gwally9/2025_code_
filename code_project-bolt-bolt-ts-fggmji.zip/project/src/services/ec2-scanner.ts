import { EC2Client, DescribeInstancesCommand } from "@aws-sdk/client-ec2";
import type { EC2Resource } from "../types/aws-resources";

export class EC2Scanner {
  private client: EC2Client;

  constructor(region: string) {
    this.client = new EC2Client({ region });
  }

  async scanResources(): Promise<EC2Resource[]> {
    try {
      const command = new DescribeInstancesCommand({});
      const response = await this.client.send(command);
      
      const instances: EC2Resource[] = [];
      
      response.Reservations?.forEach(reservation => {
        reservation.Instances?.forEach(instance => {
          instances.push({
            instanceId: instance.InstanceId || '',
            instanceType: instance.InstanceType || '',
            state: instance.State?.Name || '',
            tags: Object.fromEntries(
              instance.Tags?.map(tag => [tag.Key || '', tag.Value || '']) || []
            )
          });
        });
      });

      return instances;
    } catch (error) {
      console.error('Error scanning EC2 resources:', error);
      return [];
    }
  }
}