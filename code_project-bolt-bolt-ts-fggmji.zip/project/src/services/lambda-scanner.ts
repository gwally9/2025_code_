import { LambdaClient, ListFunctionsCommand } from "@aws-sdk/client-lambda";
import type { LambdaResource } from "../types/aws-resources";

export class LambdaScanner {
  private client: LambdaClient;

  constructor(region: string) {
    this.client = new LambdaClient({ region });
  }

  async scanResources(): Promise<LambdaResource[]> {
    try {
      const command = new ListFunctionsCommand({});
      const response = await this.client.send(command);
      
      return (response.Functions || []).map(func => ({
        functionName: func.FunctionName || '',
        runtime: func.Runtime || '',
        memory: func.MemorySize || 0,
        timeout: func.Timeout || 0
      }));
    } catch (error) {
      console.error('Error scanning Lambda resources:', error);
      return [];
    }
  }
}