import { RDSClient, DescribeDBInstancesCommand } from "@aws-sdk/client-rds";
import type { RDSResource } from "../types/aws-resources";

export class RDSScanner {
  private client: RDSClient;

  constructor(region: string) {
    this.client = new RDSClient({ region });
  }

  async scanResources(): Promise<RDSResource[]> {
    try {
      const command = new DescribeDBInstancesCommand({});
      const response = await this.client.send(command);
      
      return (response.DBInstances || []).map(instance => ({
        dbIdentifier: instance.DBInstanceIdentifier || '',
        engine: instance.Engine || '',
        status: instance.DBInstanceStatus || '',
        size: instance.DBInstanceClass || ''
      }));
    } catch (error) {
      console.error('Error scanning RDS resources:', error);
      return [];
    }
  }
}