# AWS Resource Scanner

This application scans an AWS account and generates a comprehensive report of all resources in use.

## Prerequisites

- Node.js 16 or higher
- AWS credentials configured (either through AWS CLI or environment variables)
- Appropriate AWS IAM permissions to scan resources

## Setup

1. Configure your AWS credentials:
   ```bash
   export AWS_ACCESS_KEY_ID="your-access-key"
   export AWS_SECRET_ACCESS_KEY="your-secret-key"
   export AWS_REGION="your-preferred-region"  # defaults to us-east-1
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Usage

Run the scanner:
```bash
npm run scan
```

## Features

- Scans multiple AWS services:
  - EC2 instances
  - S3 buckets
  - RDS databases
  - Lambda functions
- Provides detailed information about each resource
- Concurrent scanning for faster results
- Modular architecture for easy extension

## Output

The scanner generates a JSON report containing:
- Resource counts
- Detailed information for each resource
- Scan timestamp
- Region information