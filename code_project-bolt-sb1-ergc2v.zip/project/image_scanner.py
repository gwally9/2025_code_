import os
from pathlib import Path

class ImageScanner:
    VALID_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
    
    def scan_directory(self, directory):
        """Scan a directory recursively for image files."""
        images = []
        try:
            for root, _, files in os.walk(directory):
                for file in files:
                    if self._is_image_file(file):
                        full_path = os.path.join(root, file)
                        images.append(full_path)
        except Exception as e:
            raise Exception(f"Error scanning directory: {str(e)}")
        
        return images
    
    def _is_image_file(self, filename):
        """Check if a file is an image based on its extension."""
        return Path(filename).suffix.lower() in self.VALID_EXTENSIONS