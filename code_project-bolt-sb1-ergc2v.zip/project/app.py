from flask import Flask, render_template, jsonify, request
from image_scanner import ImageScanner
from database import Database
from image_processor import ImageProcessor
import os

app = Flask(__name__)
db = Database()
scanner = ImageScanner()
processor = ImageProcessor()

# Ensure directories exist
os.makedirs('static/thumbnails', exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/scan', methods=['POST'])
def scan_directory():
    directory = request.json.get('directory')
    if not directory:
        return jsonify({'error': 'No directory specified'}), 400
    
    try:
        images = scanner.scan_directory(directory)
        for image_path in images:
            if not db.image_exists(image_path):
                thumbnail_path = processor.create_thumbnail(image_path)
                db.add_image(image_path, thumbnail_path)
        return jsonify({'message': f'Scanned {len(images)} images'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/images')
def get_images():
    images = db.get_all_images()
    return jsonify(images)

@app.route('/api/images/<int:image_id>/tags', methods=['POST'])
def add_tag(image_id):
    tag = request.json.get('tag')
    if not tag:
        return jsonify({'error': 'No tag specified'}), 400
    
    db.add_tag(image_id, tag)
    return jsonify({'message': 'Tag added successfully'})

if __name__ == '__main__':
    db.init_db()
    app.run(debug=True, port=5000)