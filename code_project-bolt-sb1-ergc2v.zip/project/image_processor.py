from PIL import Image
import os
from pathlib import Path

class ImageProcessor:
    THUMBNAIL_SIZE = (200, 200)
    
    def create_thumbnail(self, image_path):
        """Create a thumbnail for the given image and return the thumbnail path."""
        try:
            # Generate thumbnail filename
            filename = Path(image_path).stem
            thumbnail_path = f'static/thumbnails/{filename}_thumb.jpg'
            
            # Create thumbnail if it doesn't exist
            if not os.path.exists(thumbnail_path):
                with Image.open(image_path) as img:
                    img.thumbnail(self.THUMBNAIL_SIZE)
                    img.save(thumbnail_path, 'JPEG')
            
            return thumbnail_path
        except Exception as e:
            raise Exception(f"Error creating thumbnail: {str(e)}")