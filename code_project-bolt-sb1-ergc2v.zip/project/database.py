from sqlalchemy import create_engine, Column, Integer, String, Table, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

Base = declarative_base()

# Association table for many-to-many relationship between images and tags
image_tags = Table(
    'image_tags',
    Base.metadata,
    Column('image_id', Integer, ForeignKey('images.id')),
    Column('tag_id', Integer, ForeignKey('tags.id'))
)

class Image(Base):
    __tablename__ = 'images'
    
    id = Column(Integer, primary_key=True)
    filepath = Column(String, unique=True)
    thumbnail_path = Column(String)
    tags = relationship('Tag', secondary=image_tags, back_populates='images')

class Tag(Base):
    __tablename__ = 'tags'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    images = relationship('Image', secondary=image_tags, back_populates='tags')

class Database:
    def __init__(self):
        self.engine = create_engine('sqlite:///images.db')
        self.Session = sessionmaker(bind=self.engine)
    
    def init_db(self):
        Base.metadata.create_all(self.engine)
    
    def image_exists(self, filepath):
        session = self.Session()
        exists = session.query(Image).filter_by(filepath=filepath).first() is not None
        session.close()
        return exists
    
    def add_image(self, filepath, thumbnail_path):
        session = self.Session()
        image = Image(filepath=filepath, thumbnail_path=thumbnail_path)
        session.add(image)
        session.commit()
        session.close()
    
    def add_tag(self, image_id, tag_name):
        session = self.Session()
        image = session.query(Image).get(image_id)
        if not image:
            session.close()
            return False
        
        tag = session.query(Tag).filter_by(name=tag_name).first()
        if not tag:
            tag = Tag(name=tag_name)
        
        image.tags.append(tag)
        session.commit()
        session.close()
        return True
    
    def get_all_images(self):
        session = self.Session()
        images = session.query(Image).all()
        result = [
            {
                'id': img.id,
                'filepath': img.filepath,
                'thumbnail_path': img.thumbnail_path,
                'tags': [{'id': tag.id, 'name': tag.name} for tag in img.tags]
            }
            for img in images
        ]
        session.close()
        return result