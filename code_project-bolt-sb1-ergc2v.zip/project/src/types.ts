export interface TagType {
  id: number;
  name: string;
}

export interface ImageType {
  id: number;
  filename: string;
  path: string;
  thumbnail: string;
  tags: TagType[];
  createdAt: string;
}