import express from 'express';
import multer from 'multer';
import { PrismaClient } from '@prisma/client';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs';

const prisma = new PrismaClient();
const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Upload image endpoint
app.post('/api/images', upload.single('image'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Generate thumbnail
    const thumbnailPath = `uploads/thumb_${file.filename}.jpg`;
    await sharp(file.path)
      .resize(200, 200, { fit: 'cover' })
      .toFile(thumbnailPath);

    // Save to database
    const image = await prisma.image.create({
      data: {
        filename: file.originalname,
        path: file.path,
        thumbnail: thumbnailPath,
      },
    });

    res.json(image);
  } catch (error) {
    res.status(500).json({ error: 'Failed to process image' });
  }
});

// Get all images
app.get('/api/images', async (req, res) => {
  const images = await prisma.image.findMany({
    include: { tags: true },
  });
  res.json(images);
});

// Add tag to image
app.post('/api/images/:id/tags', async (req, res) => {
  const { id } = req.params;
  const { tag } = req.body;

  try {
    const updatedImage = await prisma.image.update({
      where: { id: parseInt(id) },
      data: {
        tags: {
          connectOrCreate: {
            where: { name: tag },
            create: { name: tag },
          },
        },
      },
      include: { tags: true },
    });
    res.json(updatedImage);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add tag' });
  }
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});