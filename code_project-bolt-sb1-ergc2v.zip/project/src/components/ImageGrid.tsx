import React from 'react';
import { SimpleGrid, Card, Image, Text, Badge, Group, Button } from '@mantine/core';
import { TagInput } from './TagInput';
import { ImageType } from '../types';

interface ImageGridProps {
  images: ImageType[];
  onAddTag: (imageId: number, tag: string) => void;
}

export const ImageGrid: React.FC<ImageGridProps> = ({ images, onAddTag }) => {
  return (
    <SimpleGrid cols={6} spacing="md" verticalSpacing="md">
      {images.map((image) => (
        <Card key={image.id} shadow="sm" padding="lg">
          <Card.Section>
            <Image
              src={`http://localhost:3001/${image.thumbnail}`}
              height={160}
              alt={image.filename}
            />
          </Card.Section>

          <Group position="apart" mt="md" mb="xs">
            <Text weight={500}>{image.filename}</Text>
          </Group>

          <Group spacing={5}>
            {image.tags.map((tag) => (
              <Badge key={tag.id} color="blue">
                {tag.name}
              </Badge>
            ))}
          </Group>

          <TagInput onAddTag={(tag) => onAddTag(image.id, tag)} />
        </Card>
      ))}
    </SimpleGrid>
  );
};