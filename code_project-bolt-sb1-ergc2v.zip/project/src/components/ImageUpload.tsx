import React, { useRef } from 'react';
import { Button, Group } from '@mantine/core';
import { Upload } from 'tabler-icons-react';

interface ImageUploadProps {
  onUpload: (file: File) => void;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ onUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  return (
    <Group position="center" mb="xl">
      <input
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        ref={fileInputRef}
        onChange={handleFileChange}
      />
      <Button
        leftIcon={<Upload size={14} />}
        onClick={() => fileInputRef.current?.click()}
      >
        Upload Image
      </Button>
    </Group>
  );
};