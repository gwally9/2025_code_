import React, { useState } from 'react';
import { TextInput, Button, Group } from '@mantine/core';

interface TagInputProps {
  onAddTag: (tag: string) => void;
}

export const TagInput: React.FC<TagInputProps> = ({ onAddTag }) => {
  const [tag, setTag] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tag.trim()) {
      onAddTag(tag.trim());
      setTag('');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <Group spacing="xs" mt="sm">
        <TextInput
          placeholder="Add tag"
          value={tag}
          onChange={(e) => setTag(e.target.value)}
          size="xs"
        />
        <Button type="submit" size="xs">
          Add
        </Button>
      </Group>
    </form>
  );
};