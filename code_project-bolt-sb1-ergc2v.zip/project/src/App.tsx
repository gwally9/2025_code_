import React, { useEffect, useState } from 'react';
import { Container, Title } from '@mantine/core';
import axios from 'axios';
import { ImageGrid } from './components/ImageGrid';
import { ImageUpload } from './components/ImageUpload';
import { ImageType } from './types';

function App() {
  const [images, setImages] = useState<ImageType[]>([]);

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    try {
      const response = await axios.get('http://localhost:3001/api/images');
      setImages(response.data);
    } catch (error) {
      console.error('Failed to fetch images:', error);
    }
  };

  const handleUpload = async (file: File) => {
    const formData = new FormData();
    formData.append('image', file);

    try {
      await axios.post('http://localhost:3001/api/images', formData);
      fetchImages();
    } catch (error) {
      console.error('Failed to upload image:', error);
    }
  };

  const handleAddTag = async (imageId: number, tag: string) => {
    try {
      await axios.post(`http://localhost:3001/api/images/${imageId}/tags`, { tag });
      fetchImages();
    } catch (error) {
      console.error('Failed to add tag:', error);
    }
  };

  return (
    <Container size="xl" py="xl">
      <Title order={1} align="center" mb="xl">
        Image Gallery
      </Title>
      <ImageUpload onUpload={handleUpload} />
      <ImageGrid images={images} onAddTag={handleAddTag} />
    </Container>
  );
}

export default App;