import express from 'express';
import multer from 'multer';
import sharp from 'sharp';
import path from 'path';
import { fileURLToPath } from 'url';
import { addImage, getAllImages, addImageTag, removeImageTag } from '../db/database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.json());
app.use('/uploads', express.static('uploads'));

app.post('/api/images', upload.single('image'), async (req, res) => {
  try {
    const thumbnailPath = `uploads/thumb_${req.file.filename}.jpg`;
    
    await sharp(req.file.path)
      .resize(200, 200, { fit: 'cover' })
      .toFile(thumbnailPath);

    const result = addImage(req.file.path, thumbnailPath);
    res.json({ id: result.lastInsertRowid });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/images', (req, res) => {
  const images = getAllImages();
  res.json(images);
});

app.post('/api/images/:id/tags', (req, res) => {
  const { id } = req.params;
  const { tag } = req.body;
  
  try {
    addImageTag(id, tag);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/images/:id/tags/:tag', (req, res) => {
  const { id, tag } = req.params;
  
  try {
    removeImageTag(id, tag);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});