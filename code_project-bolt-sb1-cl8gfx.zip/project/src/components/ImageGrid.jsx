import React, { useState, useEffect } from 'react';
import { 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Chip,
  TextField,
  IconButton
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

function ImageGrid() {
  const [images, setImages] = useState([]);
  const [newTags, setNewTags] = useState({});

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    const response = await fetch('/api/images');
    const data = await response.json();
    setImages(data);
  };

  const handleAddTag = async (imageId) => {
    const tag = newTags[imageId];
    if (!tag) return;

    await fetch(`/api/images/${imageId}/tags`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tag })
    });

    setNewTags({ ...newTags, [imageId]: '' });
    fetchImages();
  };

  const handleDeleteTag = async (imageId, tag) => {
    await fetch(`/api/images/${imageId}/tags/${tag}`, {
      method: 'DELETE'
    });
    fetchImages();
  };

  return (
    <Grid container spacing={2} sx={{ padding: 2 }}>
      {images.map((image) => (
        <Grid item xs={12} sm={6} md={4} lg={2} key={image.id}>
          <Card>
            <CardMedia
              component="img"
              height="200"
              image={image.thumbnail}
              alt="Image thumbnail"
            />
            <CardContent>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
                {image.tags?.split(',').filter(Boolean).map((tag) => (
                  <Chip
                    key={tag}
                    label={tag}
                    onDelete={() => handleDeleteTag(image.id, tag)}
                    size="small"
                  />
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <TextField
                  size="small"
                  placeholder="Add tag"
                  value={newTags[image.id] || ''}
                  onChange={(e) => setNewTags({
                    ...newTags,
                    [image.id]: e.target.value
                  })}
                />
                <IconButton 
                  size="small"
                  onClick={() => handleAddTag(image.id)}
                >
                  <AddIcon />
                </IconButton>
              </div>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}