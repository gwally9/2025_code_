import Database from 'better-sqlite3';

const db = new Database('gallery.db');

// Initialize database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filepath TEXT NOT NULL,
    thumbnail TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS image_tags (
    image_id INTEGER,
    tag_id INTEGER,
    PRIMARY KEY (image_id, tag_id),
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
  );
`);

export const addImage = (filepath, thumbnail) => {
  const stmt = db.prepare('INSERT INTO images (filepath, thumbnail) VALUES (?, ?)');
  return stmt.run(filepath, thumbnail);
};

export const getAllImages = () => {
  const stmt = db.prepare(`
    SELECT i.*, GROUP_CONCAT(t.name) as tags
    FROM images i
    LEFT JOIN image_tags it ON i.id = it.image_id
    LEFT JOIN tags t ON it.tag_id = t.id
    GROUP BY i.id
    ORDER BY i.created_at DESC
  `);
  return stmt.all();
};

export const addTag = (name) => {
  const stmt = db.prepare('INSERT OR IGNORE INTO tags (name) VALUES (?)');
  return stmt.run(name);
};

export const addImageTag = (imageId, tagName) => {
  const insertTag = db.prepare('INSERT OR IGNORE INTO tags (name) VALUES (?)');
  const getTagId = db.prepare('SELECT id FROM tags WHERE name = ?');
  const linkTag = db.prepare('INSERT OR IGNORE INTO image_tags (image_id, tag_id) VALUES (?, ?)');

  const transaction = db.transaction((imageId, tagName) => {
    insertTag.run(tagName);
    const tag = getTagId.get(tagName);
    linkTag.run(imageId, tag.id);
  });

  return transaction(imageId, tagName);
};

export const removeImageTag = (imageId, tagName) => {
  const stmt = db.prepare(`
    DELETE FROM image_tags 
    WHERE image_id = ? AND tag_id IN (SELECT id FROM tags WHERE name = ?)
  `);
  return stmt.run(imageId, tagName);
};